Before using our executor here are few notes :

1 - Do not inject in literal baseplate it will crash.

2 - when you joined to a game open up executor and inject but DO NOT EXECUTE OR DO ANYTHING FOR 1 MIN. (It will crash)

3 - Join our discord!

4 - have fun!

---------------------------------------------